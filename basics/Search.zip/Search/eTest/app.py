from flask import Flask, render_template, request, redirect, url_for, session
import pandas as pd

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Load questions from Excel
df = pd.read_excel('exam_questions.xlsx')

@app.route('/')
def index():
    session['responses'] = [None] * len(df)  # Initialize responses
    return redirect(url_for('exam', question_index=0))

@app.route('/exam/<int:question_index>', methods=['GET'])
def exam(question_index):
    if question_index < 0 or question_index >= len(df):
        return redirect(url_for('index'))
    
    question = {
        'question_text': df.iloc[question_index, 0],
        'options': df.iloc[question_index, 1:5].tolist()
    }
    selected_answer = session['responses'][question_index]
    return render_template('exam.html', question=question, question_index=question_index, selected_answer=selected_answer, total_questions=len(df))

@app.route('/navigate', methods=['POST'])
def navigate():
    question_index = int(request.form['question_index'])
    action = request.form['action']
    selected_answer = request.form.get('answer')

    session['responses'][question_index] = selected_answer

    if action == 'next':
        question_index += 1
    elif action == 'previous':
        question_index -= 1
    elif action == 'submit':
        return redirect(url_for('submit'))

    return redirect(url_for('exam', question_index=question_index))

@app.route('/submit', methods=['GET'])
def submit():
    score = 0
    for i in range(len(df)):
        correct_answer = df.iloc[i, 5]  # Assuming the correct answer is in the 6th column
        if session['responses'][i] == correct_answer:
            score += 1
    return f'Your score is {score}/{len(df)}'

if __name__ == '__main__':
    app.run(debug=True)
