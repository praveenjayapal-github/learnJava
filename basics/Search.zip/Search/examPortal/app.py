import pandas as pd
from flask import Flask, render_template, request

app = Flask(__name__)

# Load questions from Excel
df = pd.read_excel('exam_questions.xlsx')

@app.route('/')
def exam():
    questions = []
    for index, row in df.iterrows():
        question = {
            'question_text': row[0],
            'options': row[1:5].tolist()
        }
        questions.append(question)
    return render_template('exam.html', questions=questions)

@app.route('/submit', methods=['POST'])
def submit_exam():
    # Get student answers and calculate score
    score = 0
    for i in range(len(df)):
        student_answer = request.form.get(f'question-{i}')
        correct_answer = df.iloc[i, 5]  # Assuming column F contains correct answers
        if student_answer == correct_answer:
            score += 1
    return f'Your score is {score}/{len(df)}'

if __name__ == '__main__':
    app.run(debug=True)
