import os
import speech_recognition as sr
import pygame

# Function to record audio
def record_audio(filename, duration=5):
    recognizer = sr.Recognizer()
    
    with sr.Microphone() as source:
        print("Listening...")
        audio_data = recognizer.record(source, duration=duration)
    
    with open(filename, "wb") as f:
        f.write(audio_data.get_wav_data())

# Function to recognize speech
def recognize_speech(filename):
    recognizer = sr.Recognizer()

    with sr.AudioFile(filename) as source:
        audio_data = recognizer.record(source)
        text = recognizer.recognize_google(audio_data)

    return text

# Function to search music files in a folder
def search_music(folder):
    music_files = []

    for file in os.listdir(folder):
        if file.endswith(".mp3"):
            music_files.append(file)

    return music_files

# Function to play music
def play_music(filename):
    pygame.mixer.init()
    pygame.mixer.music.load(filename)
    pygame.mixer.music.play()

# Example usage
if __name__ == "__main__":
    audio_file = "audio.wav"
    record_audio(audio_file)
    command = recognize_speech(audio_file)
    print("Command:", command)
    
    music_folder = "path/to/your/music/folder"
    music_files = search_music(music_folder)
    print("Music files found:", music_files)
    
    if command.lower() in ["play music", "play a song"]:
        if music_files:
            print("Playing music...")
            play_music(os.path.join(music_folder, music_files[0]))
        else:
            print("No music files found.")
    else:
        print("Command not recognized or not related to playing music.")
